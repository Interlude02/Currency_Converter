package LAB_4;
import javax.swing.JFrame;
public class ConvertApp {
    public static void main(String[] args)
    {
        ConvertFrame convertFrame = new ConvertFrame();
        convertFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //convertFrame.setSize(320, 300); // set frame size
        convertFrame.setVisible(true); // display frame
    }
}
